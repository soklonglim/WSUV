Name:		Soklong Lim
SID:		11458249
Project:	Computing Homography Transformations
Class:		CS 330 (Numerical Computing)
Due date:	December 2, 2015

Description: this is a C99 module continued from previous project. this
module is used to build an application that determines the parameters of
image transformation. it will spit out the 3x3 matrix which is the result
of homography computation.

List of files:	LUdecomp.c homography.c hmap.c LUdecomp.h makefile README.txt 
		boxtop.in shelves.in
Usage:
	1) Unzip:	tar -xvzf homography.tar.gz 
	2) Compile:	make
	3) Run: 	./homography
